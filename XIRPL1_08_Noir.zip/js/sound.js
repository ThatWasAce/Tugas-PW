const playPauseBtn = document.getElementById('playPauseBtn');
const audio = document.getElementById('audio');
const status = document.querySelector('.status');

playPauseBtn.addEventListener('click', () => {
    if (audio.paused) {
        audio.play();
        playPauseBtn.textContent = 'Pause';
        status.textContent = 'Playing';
    } else {
        audio.pause();
        playPauseBtn.textContent = 'Play';
        status.textContent = 'Paused';
    }
});