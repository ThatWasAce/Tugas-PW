document.querySelectorAll('.team-member').forEach(member => {
    member.addEventListener('mouseover', () => {
        member.classList.add('hovered');
    });

    member.addEventListener('mouseout', () => {
        member.classList.remove('hovered');
    });
});

document.addEventListener("DOMContentLoaded", function() { // Salju
    createSnowflakes(100); // Jumlah salju

    function createSnowflakes(num) {
        for (let i = 0; i < num; i++) {
            let snowflake = document.createElement("div");
            snowflake.classList.add("snowflake");
            document.body.appendChild(snowflake);

            let size = Math.random() * 5 + 2;
            snowflake.style.left = Math.random() * 100 + "vw";
            snowflake.style.width = size + "px";
            snowflake.style.height = size + "px";
            snowflake.style.animationDuration = Math.random() * 3 + 2 + "s";
            snowflake.style.opacity = Math.random() * 0.5 + 0.3;
        }
    }
});